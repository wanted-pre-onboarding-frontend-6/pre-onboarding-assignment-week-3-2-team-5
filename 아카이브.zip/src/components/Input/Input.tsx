const Input = () => {
  return <div></div>;
};
export default Input;
